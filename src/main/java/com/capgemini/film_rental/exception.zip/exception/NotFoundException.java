
package com.capgemini.film_rental.exception;
public class NotFoundException extends RuntimeException { public NotFoundException(String msg){ super(msg);} }
